const api_url=" https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=3fd2be6f0c70a2a598f084ddfb75487c&page=1s";
async function getApi(url){
    const Response=await fetch(url);
    var data=await Response.json();
    console.log(data);
    show(data);
}

getApi(api_url);

function show(data){
    let tab=
    `
    <tr>
        <th>ID</th>
        <th>Image</th>
        <th>Overview</th>
        <th>Title</th>
        <th>Rating</th>

    </tr>`
    ;
    for(let r of data.results)
    {
        tab+=`
        <tr>
            <td>${r.id}</td>
            <td><img src="${r.backdrop_path[0]}"></img></td>
            <td>${r.overview}</td>
            <td>${r.title}</td>
            <td>${r.vote_average}</td>
        </tr>
        `;
    }
    document.getElementById('phone').innerHTML=tab;
}